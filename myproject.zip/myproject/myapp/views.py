from django.shortcuts import render
from django.http import HttpResponse
from . models import *
from . forms import BookingForm
# Create your views here.

# def index(request):
#     return HttpResponse("Hello World")

# def about(request):
#         return HttpResponse("Hello World")
    

# def booking(request):
#         return HttpResponse("Hello World")
    

# def doctor(request):
#         return HttpResponse("Hello World")


# def department(request):
#       return HttpResponse("Hello World")


def index(request):
    return render(request,"index.html")

def about(request):
    return render(request,"about.html")
  
def contact(request):
    return render(request,"contact.html")  

def booking(request):
    if request.method=='POST':
        form=BookingForm(request.POST)
        if form.is_valid():
            form.save()
    
    form=BookingForm
    dict_form={
        'form':form
    }
    return render(request,"booking.html",dict_form)
    

def doctor(request):
    dict_doc={
        'doctors':Doctor.objects.all()
    }
    return render(request,"doctor.html",dict_doc)
    
    

def department(request):
    dict_dep={
        'dept':Department.objects.all()
    }
    return render(request,"department.html",dict_dep)




# def index(request):
#     # person= {
#     #     'name':'John',
#     #     'age':27
#     # }
#     # return render(request,"index.html",person)
    
    
#     # numbers={
#     #     "num1":-10
        
#     # }
#     # return render(request,"index.html",numbers)
    
    
#     # forloop={
#     #     'num':[1,2,3,4,5,6]
#     # }
        
#     return render(request,"index.html",forloop)


        
